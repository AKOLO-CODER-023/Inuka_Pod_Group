# Week 4 ETL Pipeline — Pump Sensor Readings

A modular, idempotent, config-driven ETL pipeline that extracts pump
sensor readings (pressure, temperature, status) from a Kenyan fuel depot
site, validates data quality with Great Expectations, and loads clean
data into SQLite — with logging, a halt-on-failure quality gate, and
scheduled automation.

## Data Source

`data/raw/pump_sensor_readings.csv` and `pump_sensor_readings_dirty.csv`
— schema: `timestamp, sensor_id, pressure_psi, temperature_c, status`.

## Architecture

```
data/raw/*.csv  --EXTRACT-->  raw DataFrame  --VALIDATE-->  (halt if failed)
                                                    |
                                                 (pass)
                                                    v
                                              TRANSFORM  -->  LOAD  -->  SQLite
                                                                          (idempotent)
```

## Project Structure

```
week4_etl_pipeline/
├── run_pipeline.py                  # main ETL entrypoint (extract/transform/load)
├── great_expectations_suite/
│   └── validate.py                  # 6-rule data quality suite + validation runner
├── data/
│   ├── raw/
│   │   ├── pump_sensor_readings.csv        # clean sample source (default)
│   │   └── pump_sensor_readings_dirty.csv  # deliberately dirty source, for demo
│   └── processed/
│       └── pump_sensors.db          # SQLite output (generated on run)
├── automation/
│   └── AUTOMATION_PROOF.md          # cron / Task Scheduler configuration
├── .env.example                     # config template
├── .env                             # your local config (git-ignored)
├── requirements.txt
├── pipeline.log                     # generated on run
└── README.md
```

## 1. Install dependencies

```bash
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Set up your `.env`

```bash
cp .env.example .env
```

| Variable | Meaning | Default |
|---|---|---|
| `SOURCE_CSV_PATH` | Path to the raw sensor CSV | `data/raw/pump_sensor_readings.csv` |
| `DB_PATH` | SQLite database file to load into | `data/processed/pump_sensors.db` |
| `TARGET_TABLE` | Table name | `pump_sensor_readings` |
| `LOG_PATH` | Log file path | `pipeline.log` |
| `PRESSURE_MIN_PSI` | Minimum valid pressure (psi) | `0` |
| `PRESSURE_MAX_PSI` | Maximum valid pressure (psi) | `200` |
| `TEMPERATURE_MAX_C` | Maximum valid temperature (°C) | `100` |

**Never commit `.env`** — it's git-ignored by design. `.env.example` is the
template that ships with the repo.

## 3. Run the pipeline

```bash
python run_pipeline.py
```

On success you'll see (and find in `pipeline.log`):

```
PIPELINE START: ...
EXTRACT: 12 rows, 5 columns read
VALIDATE: all data quality rules passed
TRANSFORM: dropped 0 unusable row(s); 12 rows remain
LOAD: cleared existing rows from 'pump_sensor_readings' (idempotent full refresh)
LOAD: 12 rows now in 'pump_sensor_readings'
PIPELINE SUCCESS: 12 rows loaded in 0.25s
PIPELINE END: ...
```

## 4. See the quality gate halt the pipeline

`pump_sensor_readings_dirty.csv` has real, deliberately introduced problems:
a duplicate reading, a negative pressure value, a missing sensor ID, and a
250 psi spike outside the pump's rated range. Point the pipeline at it to
see the halt-before-load behavior:

```bash
SOURCE_CSV_PATH=data/raw/pump_sensor_readings_dirty.csv python run_pipeline.py
```

Expected outcome: exit code `1`, and the log shows exactly which rules
failed — **no data is loaded**:

```
VALIDATE: FAILED — 4 rule(s) violated: [...]
PIPELINE HALTED (data quality gate): ... Halting before load.
PIPELINE END: ... (halted, no load performed)
```

## Data Quality Rules (`great_expectations_suite/validate.py`)

| # | Rule | Why |
|---|---|---|
| 1 | `sensor_id` not null | Every reading must be attributable to a pump |
| 2 | `(timestamp, sensor_id)` unique together | Prevents duplicate readings from corrupting counts |
| 3 | `pressure_psi` > 0 | A non-positive pressure reading is physically impossible |
| 4 | `pressure_psi` <= 200 | Above the pump's rated range — a sensor fault, not reality |
| 5 | `temperature_c` < 100 | Above this, the sensor is failing, not reporting reality |
| 6 | `status` in `{OK, WARNING, CRITICAL}` | Catches corrupted/unexpected status codes |

## Idempotency

Re-running the pipeline against the same source never duplicates data:

1. **Full-refresh clear** — the target table is truncated (`DELETE FROM ...`)
   before every load, so the end state only ever reflects the latest run.
2. **Composite-key upsert** — `(timestamp, sensor_id)` is the SQLite primary
   key, and rows are loaded with `INSERT OR REPLACE`, so even a partial or
   interrupted re-load can't create duplicates.

Verified: running the pipeline twice in a row against the same 12-row
source leaves exactly 12 rows in the table both times.

## Automation

See [`automation/AUTOMATION_PROOF.md`](automation/AUTOMATION_PROOF.md) for
the cron / Windows Task Scheduler configuration used to run this daily
without manual intervention.

## Logging

Every run appends to `pipeline.log` (and prints to console) with:
- Start and end timestamps
- Row counts at each stage (extracted, dropped in transform, loaded)
- Which validation rules passed/failed, by name
- Full tracebacks for unexpected errors (`logger.exception`)

## Hackathon Reflection

This pipeline follows directly from the Week 3 multi-source notebook (fuel
depot sensor + external API + SQLite). The biggest shift this week was
moving from "a notebook that produces a chart" to "a script that decides,
on its own, whether it's safe to load data" — that's the real difference
between analysis and a production pipeline. The idempotency requirement
also forced a decision that's easy to skip in a notebook: what does
"re-running this" even mean, and what should NOT happen when it does.
