# Automation Proof

This pipeline is scheduled to run automatically without manual intervention.

## Option A — Linux/macOS (cron)

Entry added via `crontab -e`, scheduled to run every day at 06:00:

```
0 6 * * * cd /home/user/week4_etl_pipeline && /home/user/week4_etl_pipeline/.venv/bin/python run_pipeline.py >> automation/cron_stdout.log 2>&1
```

Verify it's installed:

```
$ crontab -l
0 6 * * * cd /home/user/week4_etl_pipeline && /home/user/week4_etl_pipeline/.venv/bin/python run_pipeline.py >> automation/cron_stdout.log 2>&1
```

**To submit your own proof:** run `crontab -e`, paste the line above (with your
actual project path and Python path — find the latter with `which python`),
save, then run `crontab -l` and screenshot the output. Save the screenshot as
`automation/cron_screenshot.png`.

## Option B — Windows (Task Scheduler)

1. Open **Task Scheduler** → **Create Basic Task**
2. Name: `Week4 ETL Pipeline`
3. Trigger: **Daily**, start time `06:00`
4. Action: **Start a program**
   - Program/script: `C:\Users\<you>\week4_etl_pipeline\.venv\Scripts\python.exe`
   - Add arguments: `run_pipeline.py`
   - Start in: `C:\Users\<you>\week4_etl_pipeline`
5. Finish, then open the task's **Properties** to confirm the schedule.

**To submit your own proof:** after creating the task, right-click it →
**Properties**, and screenshot the **Triggers** and **Actions** tabs. Save as
`automation/task_scheduler_screenshot.png`.

## Why daily at 06:00?

Fuel depot readings accumulate throughout the day; running the pipeline
before the operations team's morning shift ensures the previous day's full
dataset is validated, cleaned, and loaded before anyone needs to query it.
