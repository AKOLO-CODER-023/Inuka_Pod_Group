"""
great_expectations_suite/validate.py
=====================================
Data quality gate for the pump sensor ETL pipeline, built with
Great Expectations (fluent / ephemeral-context API, GE >= 1.0).

Defines and runs an ExpectationSuite against the raw, freshly-extracted
DataFrame — BEFORE any transform/load happens. run_pipeline.py halts
the pipeline entirely if this validation fails.

Schema: timestamp, sensor_id, pressure_psi, temperature_c, status

Rules implemented (6 total — exceeds the 5-rule minimum):
  1. sensor_id must never be null                    (no unattributable readings)
  2. (timestamp, sensor_id) must be unique together   (no duplicate readings for the same pump at the same time)
  3. pressure_psi must be > 0                         (a non-positive reading is physically impossible)
  4. pressure_psi must be <= 200                      (above the pump's rated range — a sensor fault, not a real reading)
  5. temperature_c must be < 100                      (above this, the sensor itself is failing, not reporting a real reading)
  6. status must be one of a known set                (catches corrupted/unexpected sensor codes)
"""

import logging
import os

import great_expectations as gx
import pandas as pd

# Quiet GE's internal INFO logging / progress bars so pipeline.log stays readable
logging.getLogger("great_expectations").setLevel(logging.WARNING)

PRESSURE_MIN_PSI = float(os.getenv("PRESSURE_MIN_PSI", 0))
PRESSURE_MAX_PSI = float(os.getenv("PRESSURE_MAX_PSI", 200))
TEMPERATURE_MAX_C = float(os.getenv("TEMPERATURE_MAX_C", 100))
VALID_STATUSES = ["OK", "WARNING", "CRITICAL"]


def build_suite() -> "gx.ExpectationSuite":
    """Construct the expectation suite. Kept separate from run_validation()
    so the rule set can be unit-tested or reused (e.g. in a notebook)."""
    suite = gx.ExpectationSuite(name="pump_sensor_readings_suite")

    suite.add_expectation(
        gx.expectations.ExpectColumnValuesToNotBeNull(column="sensor_id")
    )
    suite.add_expectation(
        gx.expectations.ExpectCompoundColumnsToBeUnique(
            column_list=["timestamp", "sensor_id"]
        )
    )
    suite.add_expectation(
        gx.expectations.ExpectColumnValuesToBeBetween(
            column="pressure_psi", min_value=PRESSURE_MIN_PSI, strict_min=True
        )
    )
    suite.add_expectation(
        gx.expectations.ExpectColumnValuesToBeBetween(
            column="pressure_psi", max_value=PRESSURE_MAX_PSI
        )
    )
    suite.add_expectation(
        gx.expectations.ExpectColumnValuesToBeBetween(
            column="temperature_c", max_value=TEMPERATURE_MAX_C, strict_max=True
        )
    )
    suite.add_expectation(
        gx.expectations.ExpectColumnValuesToBeInSet(
            column="status", value_set=VALID_STATUSES
        )
    )
    return suite


def run_validation(df: pd.DataFrame):
    """Run the expectation suite against `df` and return the GE result object.

    result.success (bool) tells the caller whether to proceed.
    result.results is a list of per-expectation outcomes, used by
    run_pipeline.py to log exactly which rule(s) failed.
    """
    context = gx.get_context(mode="ephemeral")

    data_source = context.data_sources.add_pandas("pandas_source")
    data_asset = data_source.add_dataframe_asset(name="pump_sensor_readings")
    batch_definition = data_asset.add_batch_definition_whole_dataframe("full_batch")
    batch = batch_definition.get_batch(batch_parameters={"dataframe": df})

    suite = build_suite()
    context.suites.add(suite)

    return batch.validate(suite)


if __name__ == "__main__":
    # Quick manual check: `python great_expectations_suite/validate.py`
    import sys
    sample_path = sys.argv[1] if len(sys.argv) > 1 else "data/raw/pump_sensor_readings.csv"
    df = pd.read_csv(sample_path)
    result = run_validation(df)
    print(f"Validation success: {result.success}")
    for r in result.results:
        status = "PASS" if r.success else "FAIL"
        print(f"  [{status}] {r.expectation_config.type}")
