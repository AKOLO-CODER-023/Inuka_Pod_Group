"""
run_pipeline.py
================
Week 4 ETL Pipeline — Pump Sensor Readings (fuel depot pump monitoring)

A modular, idempotent, config-driven ETL pipeline that:
  1. EXTRACTS raw sensor readings from a CSV source.
  2. Validates data quality with a Great Expectations suite and HALTS
     execution if critical checks fail (see great_expectations_suite/).
  3. TRANSFORMS the readings (type coercion, derived columns, cleanup).
  4. LOADS the result into a SQLite table idempotently.

Run:
    python run_pipeline.py
"""

import logging
import os
import sqlite3
import sys
from datetime import datetime, timezone

import pandas as pd
from dotenv import load_dotenv

from great_expectations_suite.validate import run_validation

# --------------------------------------------------------------------------
# Configuration — loaded from .env (see .env.example for the template)
# --------------------------------------------------------------------------
load_dotenv()

SOURCE_CSV_PATH = os.getenv("SOURCE_CSV_PATH", "data/raw/pump_sensor_readings.csv")
DB_PATH = os.getenv("DB_PATH", "data/processed/pump_sensors.db")
TARGET_TABLE = os.getenv("TARGET_TABLE", "pump_sensor_readings")
LOG_PATH = os.getenv("LOG_PATH", "pipeline.log")

PRESSURE_MIN_PSI = float(os.getenv("PRESSURE_MIN_PSI", 0))
PRESSURE_MAX_PSI = float(os.getenv("PRESSURE_MAX_PSI", 200))
TEMPERATURE_MAX_C = float(os.getenv("TEMPERATURE_MAX_C", 100))

# --------------------------------------------------------------------------
# Logging — file + console, capturing start/end time, row counts, errors
# --------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, mode="a"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("etl_pipeline")


class PipelineValidationError(Exception):
    """Raised when the data quality gate fails and the pipeline must halt."""


# --------------------------------------------------------------------------
# EXTRACT
# --------------------------------------------------------------------------
def extract(source_path: str) -> pd.DataFrame:
    """Read raw pump sensor readings from the CSV source."""
    logger.info(f"EXTRACT: reading source file '{source_path}'")

    if not os.path.exists(source_path):
        raise FileNotFoundError(f"Source file not found: {source_path}")

    df = pd.read_csv(source_path)
    logger.info(f"EXTRACT: {len(df):,} rows, {len(df.columns)} columns read")
    return df


# --------------------------------------------------------------------------
# TRANSFORM
# --------------------------------------------------------------------------
def transform(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and enrich the extracted readings."""
    logger.info("TRANSFORM: starting cleaning and enrichment")
    before = len(df)

    df = df.copy()

    # Drop rows with no sensor_id — cannot be attributed to a pump
    df = df.dropna(subset=["sensor_id"])

    # Drop exact duplicate (timestamp, sensor_id) readings, keep the first
    df = df.drop_duplicates(subset=["timestamp", "sensor_id"], keep="first")

    # Parse timestamp
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp"])

    # Derived column: simple risk flag used by the dashboard/reporting layer
    df["is_out_of_range"] = (
        (df["pressure_psi"] < PRESSURE_MIN_PSI)
        | (df["pressure_psi"] > PRESSURE_MAX_PSI)
        | (df["temperature_c"] > TEMPERATURE_MAX_C)
    )

    # Standardize categorical text
    df["status"] = df["status"].str.upper().str.strip()

    dropped = before - len(df)
    logger.info(f"TRANSFORM: dropped {dropped} unusable row(s); {len(df):,} rows remain")
    return df


# --------------------------------------------------------------------------
# LOAD
# --------------------------------------------------------------------------
def load(df: pd.DataFrame, db_path: str, table_name: str) -> int:
    """
    Load the transformed data into SQLite, idempotently.

    Idempotency strategy (two layers, so re-running the pipeline never
    duplicates data):
      1. A UNIQUE constraint on (timestamp, sensor_id) — re-inserting the
         same reading is replaced rather than duplicated (INSERT OR REPLACE).
      2. Full-refresh clear: the target table is truncated before load,
         so re-running against the same source always yields the same
         end state, regardless of how many times it's executed.
    """
    logger.info(f"LOAD: connecting to '{db_path}'")
    os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            timestamp TEXT,
            sensor_id TEXT,
            pressure_psi REAL,
            temperature_c REAL,
            status TEXT,
            is_out_of_range INTEGER,
            loaded_at TEXT,
            PRIMARY KEY (timestamp, sensor_id)
        )
    """)

    # --- Idempotency: clear existing rows for a clean full refresh ---
    cur.execute(f"DELETE FROM {table_name}")
    logger.info(f"LOAD: cleared existing rows from '{table_name}' (idempotent full refresh)")

    load_df = df.copy()
    load_df["timestamp"] = load_df["timestamp"].astype(str)
    load_df["is_out_of_range"] = load_df["is_out_of_range"].astype(int)
    load_df["loaded_at"] = datetime.now(timezone.utc).isoformat()

    cols = ["timestamp", "sensor_id", "pressure_psi", "temperature_c",
            "status", "is_out_of_range", "loaded_at"]

    # INSERT OR REPLACE as a second idempotency layer keyed on (timestamp, sensor_id)
    cur.executemany(
        f"""INSERT OR REPLACE INTO {table_name}
            ({", ".join(cols)}) VALUES ({", ".join(["?"] * len(cols))})""",
        load_df[cols].itertuples(index=False, name=None),
    )
    conn.commit()

    row_count = cur.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]
    conn.close()

    logger.info(f"LOAD: {row_count:,} rows now in '{table_name}'")
    return row_count


# --------------------------------------------------------------------------
# MAIN
# --------------------------------------------------------------------------
def main():
    start_time = datetime.now(timezone.utc)
    logger.info("=" * 70)
    logger.info(f"PIPELINE START: {start_time.isoformat()}")
    logger.info(f"Config -> source={SOURCE_CSV_PATH}, db={DB_PATH}, table={TARGET_TABLE}")

    try:
        raw_df = extract(SOURCE_CSV_PATH)

        logger.info("VALIDATE: running Great Expectations data quality suite")
        validation_result = run_validation(raw_df)

        if not validation_result.success:
            failed = [
                r.expectation_config.type
                for r in validation_result.results
                if not r.success
            ]
            logger.error(f"VALIDATE: FAILED — {len(failed)} rule(s) violated: {failed}")
            raise PipelineValidationError(
                f"Data quality validation failed on: {failed}. Halting before load."
            )
        logger.info("VALIDATE: all data quality rules passed")

        clean_df = transform(raw_df)
        row_count = load(clean_df, DB_PATH, TARGET_TABLE)

        end_time = datetime.now(timezone.utc)
        duration = (end_time - start_time).total_seconds()
        logger.info(f"PIPELINE SUCCESS: {row_count:,} rows loaded in {duration:.2f}s")
        logger.info(f"PIPELINE END: {end_time.isoformat()}")
        logger.info("=" * 70)
        return 0

    except PipelineValidationError as e:
        end_time = datetime.now(timezone.utc)
        logger.error(f"PIPELINE HALTED (data quality gate): {e}")
        logger.info(f"PIPELINE END: {end_time.isoformat()} (halted, no load performed)")
        logger.info("=" * 70)
        return 1

    except Exception as e:
        end_time = datetime.now(timezone.utc)
        logger.exception(f"PIPELINE FAILED with an unexpected error: {e}")
        logger.info(f"PIPELINE END: {end_time.isoformat()} (failed)")
        logger.info("=" * 70)
        return 2


if __name__ == "__main__":
    sys.exit(main())
